<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>150526 2-Actor Submit Form Perm</label>
    <values>
        <field>Access__c</field>
        <value xsi:type="xsd:string">Write</value>
    </values>
    <values>
        <field>Actor_Type__c</field>
        <value xsi:type="xsd:string">Responder</value>
    </values>
    <values>
        <field>Global_Id__c</field>
        <value xsi:type="xsd:string">WSP2</value>
    </values>
    <values>
        <field>Workflow_Step_Definition_Global_Id__c</field>
        <value xsi:type="xsd:string">WSD2</value>
    </values>
</CustomMetadata>
