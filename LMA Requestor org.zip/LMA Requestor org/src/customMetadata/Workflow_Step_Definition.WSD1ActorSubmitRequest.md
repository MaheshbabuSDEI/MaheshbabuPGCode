<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>1-Actor Submit Request</label>
    <values>
        <field>Actor_Email_Template__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Actor_Type__c</field>
        <value xsi:type="xsd:string">Requestor</value>
    </values>
    <values>
        <field>Description__c</field>
        <value xsi:type="xsd:string">Submit Request with Document</value>
    </values>
    <values>
        <field>Global_Id__c</field>
        <value xsi:type="xsd:string">WSD4</value>
    </values>
    <values>
        <field>Next_Step_Global_Id__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Previous_Step_Global_Id__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Rejection_Return_Step_Global_Id__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Step_Number__c</field>
        <value xsi:type="xsd:double">1.0</value>
    </values>
    <values>
        <field>Workflow_Definition_Global_Id__c</field>
        <value xsi:type="xsd:string">WD1</value>
    </values>
</CustomMetadata>
