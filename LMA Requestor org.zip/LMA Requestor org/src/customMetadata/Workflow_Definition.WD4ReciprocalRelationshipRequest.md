<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Reciprocal Relationship</label>
    <values>
        <field>Global_Id__c</field>
        <value xsi:type="xsd:string">WD4</value>
    </values>
    <values>
        <field>Max_Rejections__c</field>
        <value xsi:type="xsd:double">0.0</value>
    </values>
    <values>
        <field>Request_Type__c</field>
        <value xsi:type="xsd:string">Reciprocal Relationship</value>
    </values>
</CustomMetadata>
