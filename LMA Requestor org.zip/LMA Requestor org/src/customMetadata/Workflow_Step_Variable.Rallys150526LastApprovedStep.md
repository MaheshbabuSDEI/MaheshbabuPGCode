<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Rallys 150526 Last Approved Step</label>
    <values>
        <field>Condition__c</field>
        <value xsi:type="xsd:string">EQUALS</value>
    </values>
    <values>
        <field>Field__c</field>
        <value xsi:type="xsd:string">Approved</value>
    </values>
    <values>
        <field>Global_Id__c</field>
        <value xsi:type="xsd:string">WSV1</value>
    </values>
    <values>
        <field>Object__c</field>
        <value xsi:type="xsd:string">Workflow_Instance__c</value>
    </values>
    <values>
        <field>Value__c</field>
        <value xsi:type="xsd:string">TRUE</value>
    </values>
    <values>
        <field>Workflow_Step_Action_Global_Id__c</field>
        <value xsi:type="xsd:string">WSA1</value>
    </values>
</CustomMetadata>
