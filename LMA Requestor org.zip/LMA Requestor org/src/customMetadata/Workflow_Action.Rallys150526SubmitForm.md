<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Rallys 150526 Submit Form</label>
    <values>
        <field>Action_Type__c</field>
        <value xsi:type="xsd:string">Submit</value>
    </values>
    <values>
        <field>Apex_Method__c</field>
        <value xsi:type="xsd:string">Move Forward</value>
    </values>
    <values>
        <field>Global_Id__c</field>
        <value xsi:type="xsd:string">WA1</value>
    </values>
</CustomMetadata>
