<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Rallys 150526 Submit Request</label>
    <values>
        <field>Global_Id__c</field>
        <value xsi:type="xsd:string">WSA3</value>
    </values>
    <values>
        <field>Human_Action__c</field>
        <value xsi:type="xsd:string">Submit</value>
    </values>
    <values>
        <field>Workflow_Action_Global_Id__c</field>
        <value xsi:type="xsd:string">WA2</value>
    </values>
    <values>
        <field>Workflow_Step_Definition_Global_Id__c</field>
        <value xsi:type="xsd:string">WSD1</value>
    </values>
</CustomMetadata>
